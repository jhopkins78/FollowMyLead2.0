import json
import jwt
import os
import datetime
from lambda_db import get_db_session
from lambda_models import User

def register(event, context):
    try:
        # Parse request body
        body = json.loads(event['body'])
        email = body.get('email')
        password = body.get('password')
        username = body.get('name')  # assuming 'name' is sent as username
        
        if not email or not password or not username:
            return {
                'statusCode': 400,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Credentials': True,
                },
                'body': json.dumps({'error': 'Email, password and name are required'})
            }
        
        # Get database session
        session = get_db_session()
        
        try:
            # Check if user exists
            existing_user = session.query(User).filter_by(email=email).first()
            if existing_user:
                return {
                    'statusCode': 409,
                    'headers': {
                        'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Credentials': True,
                    },
                    'body': json.dumps({'error': 'Email already registered'})
                }
            
            # Create new user
            user = User(email=email, username=username)
            user.set_password(password)
            
            session.add(user)
            session.commit()
            
            # Generate token
            token = jwt.encode({
                'user_id': user.id,
                'exp': datetime.datetime.utcnow() + datetime.timedelta(days=1)
            }, os.environ['JWT_SECRET_KEY'], algorithm='HS256')
            
            return {
                'statusCode': 200,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Credentials': True,
                },
                'body': json.dumps({
                    'token': token,
                    'user': user.to_dict()
                })
            }
        except Exception as e:
            session.rollback()
            raise e
            
    except Exception as e:
        print(f"Error in register: {str(e)}")  # This will show in CloudWatch logs
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': True,
            },
            'body': json.dumps({'error': str(e)})
        }
    finally:
        session.close()

def login(event, context):
    try:
        # Parse request body
        body = json.loads(event['body'])
        email = body.get('email')
        password = body.get('password')
        
        if not email or not password:
            return {
                'statusCode': 400,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Credentials': True,
                },
                'body': json.dumps({'error': 'Email and password are required'})
            }
        
        # Get database session
        session = get_db_session()
        
        try:
            # Find user
            user = session.query(User).filter_by(email=email).first()
            if not user or not user.check_password(password):
                return {
                    'statusCode': 401,
                    'headers': {
                        'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Credentials': True,
                    },
                    'body': json.dumps({'error': 'Invalid email or password'})
                }
            
            # Generate token
            token = jwt.encode({
                'user_id': user.id,
                'exp': datetime.datetime.utcnow() + datetime.timedelta(days=1)
            }, os.environ['JWT_SECRET_KEY'], algorithm='HS256')
            
            return {
                'statusCode': 200,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Credentials': True,
                },
                'body': json.dumps({
                    'token': token,
                    'user': user.to_dict()
                })
            }
        except Exception as e:
            session.rollback()
            raise e
            
    except Exception as e:
        print(f"Error in login: {str(e)}")  # This will show in CloudWatch logs
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': True,
            },
            'body': json.dumps({'error': str(e)})
        }
    finally:
        session.close()
